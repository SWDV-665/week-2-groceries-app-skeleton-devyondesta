// create a class
class Grocery {
    name: string;
    quantity: number;
    price: number;

    constructor(n: string, q: number, p: number){
        this.name = n;
        this.quantity = q;
        this.price = p;
    }

    format() {
        return `${this.name} ${this.quantity} -> ${this.price}`;
    }

}

var list_of_items = [];
const arr: Grocery[] = [];
const add_btn = document.getElementById('add') as HTMLInputElement;

add_btn?.addEventListener('click', function (event) {
    const el_name = document.getElementById("name") as HTMLInputElement;
    const el_quantity = document.getElementById("quantity") as HTMLInputElement;
    const el_price = document.getElementById("price") as HTMLInputElement;
    const name_value = el_name?.value;
    const quantity_value = parseInt(el_quantity?.value);
    const price_value = parseInt(el_price?.value);
    var obj = new Grocery(name_value, quantity_value, price_value);
    arr.push(obj);
    
    add_grocery();
        
  });
    
  function add_grocery(){
    var ele = document.getElementById("app")!;
    ele.textContent = '';
    arr.forEach(function (e) {
        var p = document.createElement("p");
        p.textContent = e.format();
        ele.appendChild(p);
    });
}


